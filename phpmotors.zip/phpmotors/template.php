<?php include_once 'views/header.php'; 

echo '<h1>Content Title Here</h1>';

include_once 'views/footer.php';

?>

