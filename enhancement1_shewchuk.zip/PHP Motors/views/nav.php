
    <nav>
        <a href="home.php">Home</a>
        <a href="#">Classic</a>
        <a href="#">Sports</a>
        <a href="#">SUV</a>
        <a href="#">Trucks</a>
        <a href="#">Used</a>
    </nav>
