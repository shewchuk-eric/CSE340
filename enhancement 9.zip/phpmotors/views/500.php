<?php $pageTitle = "Database connection failed || PHP Motors, inc.";
    include_once 'header.php'; 

echo '<h1>Connection failed</h1>';

include_once 'footer.php';

?>