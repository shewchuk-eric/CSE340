<?php include_once 'header.php'; 

echo '<h1>Connection failed</h1>';

include_once 'footer.php';

?>